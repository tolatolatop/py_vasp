MATERIALS = [""]
STRUCTURE = [""]
SCALE = [""]
SAVEPATH = {"root":"/home/zzk/PYLADA/database/",
            "INCAR":"ORGINCAR",
            "POTCAR":"$PAW/"}
COMMON = {"nodeParams":{"n":20,"ppn":4}}